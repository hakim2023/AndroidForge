# Medicine Helper — Android

A deliberately simple medicine routine for an older person.

## Routine
Press START 45 minutes before eating. The app immediately shows Medicine 1, then reminders occur at +5 min (Medicine 2), +15 min (Medicine 3), +45 min (eat), and +65 min (Medicine 4).

Each medicine has a large confirmation button. The app stores the current step so the screen remains understandable after reopening.

## Personalization
Open Settings to enter the four medicine names and select photos from the phone.

## Build
Open this folder in Android Studio and let Gradle sync. The project targets Android 15 (API 35), min Android 8.0 (API 26).

The app does not provide medical advice and does not alter prescribed timing. Enter the exact schedule prescribed by the doctor/pharmacist.
